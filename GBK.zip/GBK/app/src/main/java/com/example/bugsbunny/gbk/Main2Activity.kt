package com.example.bugsbunny.gbk

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main2.*

class Main2Activity : AppCompatActivity() {
    private lateinit var mp : MediaPlayer


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)


        Button2.setOnClickListener{
            val intent2 = Intent(this, Main3Activity::class.java)
                startActivity(intent2)
            // tombol menuju gambang
        }
        Button3.setOnClickListener {
            val intent3 = Intent(this,Main4Activity::class.java)
                startActivity(intent3)
            // tombol menuju kromong
        }
        Button4.setOnClickListener{
            val intent4 = Intent(this,Main5Activity::class.java)
                startActivity(intent4)
            // tombol menuju kendhang
        }
        Button5.setOnClickListener{
            val intent5 = Intent(this,Main6Activity::class.java)
                startActivity(intent5)
            //tombol menuju kecrek
        }

        Button6.setOnClickListener{
            val intent6 = Intent(this,Main7Activity::class.java)
            startActivity(intent6)
            //tombol menuju gong
        }



        }





}

