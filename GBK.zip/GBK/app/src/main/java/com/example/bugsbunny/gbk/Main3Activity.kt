package com.example.bugsbunny.gbk

import android.media.AudioManager
import android.media.SoundPool
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView

class Main3Activity : AppCompatActivity() {

    internal lateinit var ge : ImageView
    internal lateinit var ge1: ImageView
    internal lateinit var ae : ImageView
    internal lateinit var ae1: ImageView
    internal lateinit var ce1: ImageView
    internal lateinit var ce2: ImageView
    internal lateinit var de1: ImageView
    internal lateinit var de2: ImageView
    internal lateinit var ee1: ImageView
    internal lateinit var ee2: ImageView

    private var soundPool: SoundPool? = null

    private var sound_ge:  Int = 0
    private var sound_ge1: Int = 0
    private var sound_ae:  Int = 0
    private var sound_ae1: Int = 0
    private var sound_ce1: Int = 0
    private var sound_ce2: Int = 0
    private var sound_de1: Int = 0
    private var sound_de2: Int = 0
    private var sound_ee1: Int = 0
    private var sound_ee2: Int = 0





    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        ge = findViewById<View>(R.id.ge)   as ImageView
        ge1 = findViewById<View>(R.id.ge1) as ImageView
        ae = findViewById<View>(R.id.ae)   as ImageView
        ae1 = findViewById<View>(R.id.ae1) as ImageView
        ce1 = findViewById<View>(R.id.ce1) as ImageView
        ce2 = findViewById<View>(R.id.ce2) as ImageView
        de1 = findViewById<View>(R.id.de1) as ImageView
        de2 = findViewById<View>(R.id.de2) as ImageView
        ee1 = findViewById<View>(R.id.ee1) as ImageView
        ee2 = findViewById<View>(R.id.ee2) as ImageView

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            soundPool = SoundPool.Builder().setMaxStreams(5).build()
        } else {
            soundPool = SoundPool(5, AudioManager.STREAM_MUSIC, 0)
        }

        sound_ge = soundPool!!.load(this, R.raw. ge, 1)
        sound_ge1 = soundPool!!.load(this, R.raw.ge1, 1)
        sound_ae = soundPool!!.load(this, R.raw.ae, 1)
        sound_ae1 = soundPool!!.load(this, R.raw.ae1, 1)
        sound_ce1 = soundPool!!.load(this, R.raw.ce1, 1)
        sound_ce2 = soundPool!!.load(this, R.raw.ce2, 1)
        sound_de1 = soundPool!!.load(this, R.raw.de1, 1)
        sound_de2 = soundPool!!.load(this, R.raw.de2, 1)
        sound_ee1 = soundPool!!.load(this, R.raw.ee1, 1)
        sound_ee2 = soundPool!!.load(this, R.raw.ee2, 1)

        ge.setOnClickListener { soundPool!!.play(sound_ge, 1f, 1f, 0, 0, 1f) }
        ge1.setOnClickListener { soundPool!!.play(sound_ge1, 1f, 1f, 0, 0, 1f) }
        ae.setOnClickListener { soundPool!!.play(sound_ae, 1f, 1f, 0, 0, 1f) }
        ae1.setOnClickListener { soundPool!!.play(sound_ae1, 1f, 1f, 0, 0, 1f) }
        ce1.setOnClickListener { soundPool!!.play(sound_ce1, 1f, 1f, 0, 0, 1f) }
        ce2.setOnClickListener { soundPool!!.play(sound_ce2, 1f, 1f, 0, 0, 1f) }
        de1.setOnClickListener { soundPool!!.play(sound_de1, 1f, 1f, 0, 0, 1f) }
        de2.setOnClickListener { soundPool!!.play(sound_de2, 1f, 1f, 0, 0, 1f) }
        ee1.setOnClickListener { soundPool!!.play(sound_ee1, 1f, 1f, 0, 0, 1f) }
        ee2.setOnClickListener { soundPool!!.play(sound_ee2, 1f, 1f, 0, 0, 1f) }







    }
}
