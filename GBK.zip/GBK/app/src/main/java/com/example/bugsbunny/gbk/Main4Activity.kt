package com.example.bugsbunny.gbk

import android.media.AudioManager
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main4.*

class Main4Activity : AppCompatActivity() {

    internal lateinit var c: Button
    internal lateinit var c1: Button
    internal lateinit var d: Button
    internal lateinit var d1: Button
    internal lateinit var e: Button
    internal lateinit var e1: Button
    internal lateinit var g: Button
    internal lateinit var g1: Button
    internal lateinit var a: Button
    internal lateinit var a1: Button

    private var soundPool: SoundPool? = null

    private var sound_c: Int = 0
    private var sound_c1: Int = 0
    private var sound_d: Int = 0
    private var sound_d1: Int = 0
    private var sound_e: Int = 0
    private var sound_e1: Int = 0
    private var sound_g: Int = 0
    private var sound_g1: Int = 0
    private var sound_a: Int = 0
    private var sound_a1: Int = 0





    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main4)

        c = findViewById<View>(R.id.c) as Button
        c1 = findViewById<View>(R.id.c1) as Button
        d = findViewById<View>(R.id.d) as Button
        d1 = findViewById<View>(R.id.d1) as Button
        e = findViewById<View>(R.id.e) as Button
        e1 = findViewById<View>(R.id.e1) as Button
        g = findViewById<View>(R.id.g) as Button
        g1 = findViewById<View>(R.id.g1) as Button
        a = findViewById<View>(R.id.a) as Button
        a1 = findViewById<View>(R.id.a1) as Button

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            soundPool = SoundPool.Builder().setMaxStreams(5).build()
        } else {
            soundPool = SoundPool(5, AudioManager.STREAM_MUSIC, 0)
        }

        sound_c = soundPool!!.load(this, R.raw. c, 1)
        sound_c1 = soundPool!!.load(this, R.raw.c1, 1)
        sound_d = soundPool!!.load(this, R.raw.d, 1)
        sound_d1 = soundPool!!.load(this, R.raw.d1, 1)
        sound_e = soundPool!!.load(this, R.raw.e, 1)
        sound_e1 = soundPool!!.load(this, R.raw.e1, 1)
        sound_g = soundPool!!.load(this, R.raw.g, 1)
        sound_g1 = soundPool!!.load(this, R.raw.g1, 1)
        sound_a = soundPool!!.load(this, R.raw.a, 1)
        sound_a1 = soundPool!!.load(this, R.raw.a1, 1)

        c.setOnClickListener { soundPool!!.play(sound_a, 1f, 1f, 0, 0, 1f) }
        c1.setOnClickListener { soundPool!!.play(sound_a1, 1f, 1f, 0, 0, 1f) }
        d.setOnClickListener { soundPool!!.play(sound_g, 1f, 1f, 0, 0, 1f) }
        d1.setOnClickListener { soundPool!!.play(sound_g1, 1f, 1f, 0, 0, 1f) }
        e.setOnClickListener { soundPool!!.play(sound_c, 1f, 1f, 0, 0, 1f) }
        e1.setOnClickListener { soundPool!!.play(sound_e1, 1f, 1f, 0, 0, 1f) }
        g.setOnClickListener { soundPool!!.play(sound_e, 1f, 1f, 0, 0, 1f) }
        g1.setOnClickListener { soundPool!!.play(sound_d1, 1f, 1f, 0, 0, 1f) }
        a.setOnClickListener { soundPool!!.play(sound_d, 1f, 1f, 0, 0, 1f) }
        a1.setOnClickListener { soundPool!!.play(sound_c1, 1f, 1f, 0, 0, 1f) }







    }
}
