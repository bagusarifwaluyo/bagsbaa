package com.example.bugsbunny.gbk

import android.media.AudioManager
import android.media.SoundPool
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView

class Main5Activity : AppCompatActivity() {

    internal lateinit var duk : Button
    internal lateinit var pak : Button
    internal lateinit var duk1 : Button
    internal lateinit var pak1 : Button
    internal lateinit var duk2 : Button
    internal lateinit var pak2 : Button

    private var soundPool: SoundPool? = null

    private var sound_duk:  Int = 0
    private var sound_pak:  Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main5)

        duk = findViewById<View>(R.id.duk)   as Button
        pak = findViewById<View>(R.id.pak)   as Button
        duk1 = findViewById<View>(R.id.duk1)   as Button
        pak1 = findViewById<View>(R.id.pak1)   as Button
        duk2 = findViewById<View>(R.id.duk2)   as Button
        pak2 = findViewById<View>(R.id.pak2)   as Button

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            soundPool = SoundPool.Builder().setMaxStreams(5).build()
        } else {
            soundPool = SoundPool(5, AudioManager.STREAM_MUSIC, 0)
        }

        sound_duk = soundPool!!.load(this, R.raw. duk, 1)
        sound_pak = soundPool!!.load(this, R.raw.pak, 1)

        duk.setOnClickListener { soundPool!!.play(sound_duk, 1f, 1f, 0, 0, 1f) }
        pak.setOnClickListener { soundPool!!.play(sound_pak, 1f, 1f, 0, 0, 1f) }
        duk1.setOnClickListener { soundPool!!.play(sound_duk, 1f, 1f, 0, 0, 1f) }
        pak1.setOnClickListener { soundPool!!.play(sound_pak, 1f, 1f, 0, 0, 1f) }
        duk2.setOnClickListener { soundPool!!.play(sound_duk, 1f, 1f, 0, 0, 1f) }
        pak2.setOnClickListener { soundPool!!.play(sound_pak, 1f, 1f, 0, 0, 1f) }
    }
}