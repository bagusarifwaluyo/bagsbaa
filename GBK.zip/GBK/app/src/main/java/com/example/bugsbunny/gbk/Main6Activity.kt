package com.example.bugsbunny.gbk

import android.media.AudioManager
import android.media.SoundPool
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView

class Main6Activity : AppCompatActivity() {

    internal lateinit var crek : ImageView
    internal lateinit var crak : ImageView

    private var soundPool: SoundPool? = null

    private var sound_crek:  Int = 0
    private var sound_crak:  Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main6)

        crek = findViewById<View>(R.id.crek)   as ImageView
        crak = findViewById<View>(R.id.crak)  as ImageView

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            soundPool = SoundPool.Builder().setMaxStreams(5).build()
        } else {
            soundPool = SoundPool(5, AudioManager.STREAM_MUSIC, 0)
        }

        sound_crek = soundPool!!.load(this, R.raw. crek, 1)
        sound_crak = soundPool!!.load(this, R.raw.crak, 1)

        crek.setOnClickListener { soundPool!!.play(sound_crek, 1f, 1f, 0, 0, 1f) }
        crak.setOnClickListener { soundPool!!.play(sound_crak, 1f, 1f, 0, 0, 1f) }
    }
}
