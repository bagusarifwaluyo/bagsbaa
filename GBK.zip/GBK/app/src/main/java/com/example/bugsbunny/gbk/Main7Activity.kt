package com.example.bugsbunny.gbk

import android.media.AudioManager
import android.media.SoundPool
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView

class Main7Activity : AppCompatActivity() {

    internal lateinit var dang : ImageView
    internal lateinit var dong : ImageView

    private var soundPool: SoundPool? = null

    private var sound_dang:  Int = 0
    private var sound_dong:  Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main7)

        dang = findViewById<View>(R.id.dang)   as ImageView
        dong = findViewById<View>(R.id.dong)   as ImageView

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            soundPool = SoundPool.Builder().setMaxStreams(5).build()
        } else {
            soundPool = SoundPool(5, AudioManager.STREAM_MUSIC, 0)
        }

        sound_dang = soundPool!!.load(this, R.raw. dang, 1)
        sound_dong = soundPool!!.load(this, R.raw.dong, 1)

        dang.setOnClickListener { soundPool!!.play(sound_dang, 1f, 1f, 0, 0, 1f) }
        dong.setOnClickListener { soundPool!!.play(sound_dong, 1f, 1f, 0, 0, 1f) }
    }
}
