import React, { Component } from 'react';
import { View, Text, Button, StyleSheet, TouchableOpacity, } from 'react-native';

export class Settings extends Component {
  render() {
    return (
       <View style={styles.container}>
        <Text>Masuk Ke Detik screen</Text>
        <Button onPress={() => this.props.navigation.navigate('HomeScreen')}
        title="Detik"color="#841584"/>
        <Button onPress={() => this.props.navigation.navigate('TeknobisaScreen')}
        title="Teknobisa"color="#841584"/>
      </View>
    )
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  buttonContainer: {
     margin: 20
   },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  }
});


export default Settings;
